<?php
 header("Access-Control-Allow-Origin: *");
 $con = mysqli_connect("localhost","id8390385_tugas3","fatimah","id8390385_tugas3") or die ("could not connect database");
?>