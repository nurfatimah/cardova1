<?php
 include "db.php";
 if(isset($_POST['update']))
 {
 $id_m=$_POST['id_m'];
 $nama_baak=$_POST['nama_baak'];
 $jumlah=$_POST['jumlah'];
 $harga=$_POST['harga'];

 
 $q=mysqli_query($con,"UPDATE `baak` SET `id_m`='$id_m',`nama_baak`='$nama_baak',`jumlah`='$jumlah',`harga`='$harga' where `id_m`='$id_m'");
 if($q)
 echo "success";
 else
 echo "error";
 }
 ?>