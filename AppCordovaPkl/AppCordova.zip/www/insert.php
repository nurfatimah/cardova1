<?php
 include "db.php";
 if(isset($_POST['insert']))
 {
 $id_m=$_POST['id_m'];
 $merk=$_POST['merk'];
 $jumlahl=$_POST['jumlahl'];
 $harga=$_POST['harga'];
 
 
 $q=mysqli_query($con,"INSERT INTO `baak` (`id_m`,`merk`,`jumlahl`,`harga`,`alamat`) VALUES ('$id_m','$merk','$jumlahl','$harga')");
 if($q)
  echo "success";
 else
  echo "error";
 }
 ?>